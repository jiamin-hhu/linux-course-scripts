
void swap(int* a, int* b);
int increaseBy(int source, int step);

