for i in {1..100}; do sleep 1;  echo $i >> result ; done
