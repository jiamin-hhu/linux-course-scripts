#!/bin/bash

pwd
cd /home/jiamin/.ssh
echo -n "after goto, the pwd is: "
pwd
