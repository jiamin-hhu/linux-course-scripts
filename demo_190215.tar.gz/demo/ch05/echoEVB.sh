#!/bin/bash
echo $B
